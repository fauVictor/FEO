export default
[
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
    {
        question: 'To be or not to be ?',
        answers: [
            {
                answer: 'yes',
                vote: 50
            },
            {
                answer: 'No',
                vote: 15
            },
            {
                answer: 'yup',
                vote: 8
            },
            {
                answer: 'yeah',
                vote: 2
            },
            {
                answer: 'Maybe',
                vote: 14
            },
            {
                answer: 'yup',
                vote: 10
            },
            {
                answer: 'yeah',
                vote: 5
            },
        ]
    },
]
